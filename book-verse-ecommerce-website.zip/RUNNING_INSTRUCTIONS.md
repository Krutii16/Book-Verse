# BookVerse - How to Run the Application

Complete step-by-step instructions to get BookVerse running locally.

## Prerequisites Check

Before starting, ensure you have:
- Node.js 18+ installed (`node --version`)
- npm installed (`npm --version`)
- MongoDB running locally OR MongoDB Atlas account set up

### Install Node.js (if needed)
https://nodejs.org/ - Download LTS version

### Install MongoDB (if local)

**Windows:**
1. Download from https://www.mongodb.com/try/download/community
2. Run installer and follow prompts
3. MongoDB should start automatically

**macOS:**
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

**Linux:**
```bash
sudo apt-get update
sudo apt-get install -y mongodb
sudo systemctl start mongodb
```

## Step-by-Step Setup

### Step 1: Navigate to Project Directory

```bash
cd bookverse
```

### Step 2: Install All Dependencies

This installs dependencies for root, server, and client:

```bash
npm run install-all
```

This will:
- Install root dependencies (concurrently)
- Install server dependencies (Express, Mongoose, etc.)
- Install client dependencies (Angular, Tailwind, etc.)

Takes ~3-5 minutes depending on internet speed.

### Step 3: Configure MongoDB

**Option A: Local MongoDB (Recommended for development)**

Make sure MongoDB is running:
```bash
# Windows (should run automatically)
net start MongoDB

# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongodb

# Verify it's running
mongosh
# You should see a MongoDB shell - type 'exit' to close
```

**Option B: MongoDB Atlas (Cloud)**

1. Go to https://www.mongodb.com/cloud/atlas
2. Create free account and cluster
3. Get connection string
4. Update `server/.env`:
   ```
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/bookverse
   ```

### Step 4: Seed Database with Sample Data

```bash
npm run seed
```

This will create:
- 50+ sample books
- 8 genres
- 10+ moods
- 20+ keywords

Takes ~1 minute.

### Step 5: Start the Application

```bash
npm run dev
```

This starts both backend and frontend concurrently:
- **Backend API**: http://localhost:5000
- **Frontend UI**: http://localhost:4200

The terminal will show both services starting. Wait for both to be ready.

### Step 6: Open in Browser

Open your browser and go to:
```
http://localhost:4200
```

You should see the BookVerse homepage!

## Testing the Application

### View API Documentation

API is running at:
```
http://localhost:5000/api
```

Try this in browser:
```
http://localhost:5000/api/books
```

You should see JSON list of books.

### Test User Credentials

After seeding, you can login with:
- **Email**: admin@bookverse.com
- **Password**: admin123

Or create your own account via the Register page.

### Test Admin Panel

Login with admin credentials, then navigate to:
```
http://localhost:4200/admin
```

## Common Commands

```bash
# Start both (recommended)
npm run dev

# Start only backend
npm run server

# Start only frontend
npm run client

# Reseed database
npm run seed

# Build for production
npm run build

# Build only backend
npm run build:server

# Build only frontend
npm run build:client
```

## Troubleshooting

### Issue: "Cannot find module" error

**Solution:** Reinstall dependencies
```bash
npm run install-all
```

### Issue: MongoDB connection error

**Check if running:**
```bash
# Windows
tasklist | findstr mongod

# macOS/Linux
ps aux | grep mongod
```

**Start MongoDB:**
```bash
# Windows: net start MongoDB
# macOS: brew services start mongodb-community
# Linux: sudo systemctl start mongodb
```

### Issue: Port 5000 or 4200 already in use

**Find and kill process:**

Windows:
```bash
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

macOS/Linux:
```bash
lsof -i :5000
kill -9 <PID>
```

Or change port in `server/.env`:
```
PORT=5001
```

### Issue: Angular not starting

Check Angular version and try:
```bash
cd client
ng version
npm start
```

## Project Features to Try

### 1. Browse Books
- Click "Books" in navigation
- Use filters: Genre, Price, Rating
- Search by title or author

### 2. Mood-Based Discovery
- Click "Find by Mood"
- Select a mood (Happy, Adventurous, etc.)
- See matching books

### 3. Shopping
- Click "Add to Cart" on any book
- View cart (cart icon in header)
- Checkout

### 4. Reviews
- Go to any book detail
- Scroll to reviews section
- Add your review

### 5. Admin Panel (as admin@bookverse.com)
- Go to http://localhost:4200/admin
- Manage books, genres, moods
- View dashboard statistics

## Performance Tips

- Backend API caching enabled for book listings
- Frontend uses RxJS for efficient data handling
- Cart persists locally in browser

## Next Steps

1. ✅ Application is running
2. 📖 Read `/server/README.md` for backend details
3. 📖 Read `/client/README.md` for frontend details
4. 🏗️ Check `PROJECT_STRUCTURE.md` for code organization
5. 🔌 Review `API_IMPLEMENTATION_GUIDE.md` for all endpoints

## File Structure Quick Reference

```
bookverse/
├── package.json          # Root scripts (dev, seed, build)
├── server/
│   ├── .env             # Backend config (DATABASE, JWT_SECRET)
│   ├── src/
│   │   ├── server.ts    # Express app entry point
│   │   ├── models/      # Mongoose schemas
│   │   ├── controllers/ # API handlers
│   │   └── routes/      # API endpoints
│   └── package.json     # Backend dependencies
├── client/
│   ├── src/
│   │   ├── main.ts      # Angular entry point
│   │   ├── app/
│   │   │   ├── app.routes.ts    # Routes
│   │   │   ├── core/            # Services, guards
│   │   │   └── features/        # Pages
│   │   └── environments/        # Config
│   └── package.json     # Frontend dependencies
└── README.md
```

## Architecture Overview

```
Browser
   ↓
Angular Frontend (http://localhost:4200)
   ↓
HTTP Requests
   ↓
Express Backend API (http://localhost:5000)
   ↓
MongoDB Database (localhost:27017 or Atlas)
```

## Support

If you encounter issues:
1. Check this file first
2. Check `README.md` for more details
3. Review console output for error messages
4. Ensure MongoDB is running
5. Verify Node.js version (18+)

## Success Indicators

When everything is working:
- ✅ Terminal shows "Angular Live Development Server" listening on port 4200
- ✅ Terminal shows "Express server running on port 5000"
- ✅ Browser shows BookVerse homepage
- ✅ Can browse books and see data
- ✅ Can login with test credentials
- ✅ Admin panel is accessible

## Production Deployment

When ready to deploy:
```bash
npm run build
```

This creates:
- `/server/dist/` - Production backend
- `/client/dist/` - Production frontend

See main README.md for deployment options.

---

**You're all set! Start building with BookVerse 📚**
