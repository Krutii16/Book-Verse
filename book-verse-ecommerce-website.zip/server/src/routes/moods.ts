import { Router } from 'express';
import * as moodController from '../controllers/moodController';
import { authMiddleware, adminMiddleware } from '../middleware/auth';

const router = Router();

router.get('/', moodController.getAllMoods);
router.post('/', authMiddleware, adminMiddleware, moodController.createMood);
router.put('/:id', authMiddleware, adminMiddleware, moodController.updateMood);
router.delete('/:id', authMiddleware, adminMiddleware, moodController.deleteMood);

export default router;
