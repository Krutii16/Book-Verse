import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private apiUrl = 'http://localhost:5000/api/books';

  constructor(private http: HttpClient) {}

  getAllBooks(page: number = 1, limit: number = 12): Observable<any> {
    const params = new HttpParams().set('page', page).set('limit', limit);
    return this.http.get<any>(`${this.apiUrl}`, { params });
  }

  getBookById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  getFeaturedBooks(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/featured`);
  }

  getBestsellers(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/bestsellers`);
  }

  searchBooks(query: string): Observable<any> {
    const params = new HttpParams().set('query', query);
    return this.http.get<any>(`${this.apiUrl}/search`, { params });
  }

  filterBooks(filters: any): Observable<any> {
    let params = new HttpParams();
    
    if (filters.genre) params = params.set('genre', filters.genre);
    if (filters.minPrice) params = params.set('minPrice', filters.minPrice);
    if (filters.maxPrice) params = params.set('maxPrice', filters.maxPrice);
    if (filters.rating) params = params.set('rating', filters.rating);
    if (filters.language) params = params.set('language', filters.language);
    if (filters.moods) params = params.set('moods', filters.moods);
    if (filters.keywords) params = params.set('keywords', filters.keywords);

    return this.http.get<any>(`${this.apiUrl}/filter`, { params });
  }

  createBook(book: Book): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}`, book);
  }

  updateBook(id: string, book: Partial<Book>): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, book);
  }

  deleteBook(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
}
