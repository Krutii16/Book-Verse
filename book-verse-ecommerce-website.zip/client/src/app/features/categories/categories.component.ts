import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BookService } from '../../core/services/book.service';
import { MetadataService } from '../../core/services/metadata.service';
import { Genre, Book } from '../../core/models/book.model';

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-gray-50 py-12 px-4">
      <div class="max-w-7xl mx-auto">
        <h1 class="text-4xl font-bold mb-12">Browse by Category</h1>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <div *ngFor="let genre of genres" class="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition cursor-pointer" [routerLink]="['/books']" [queryParams]="{ genre: genre.name }">
            <h3 class="text-2xl font-bold text-blue-600">{{ genre.name }}</h3>
            <p class="text-gray-600 mt-2">{{ genre.description || 'Explore this category' }}</p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CategoriesComponent implements OnInit {
  genres: Genre[] = [];

  constructor(private metadataService: MetadataService) {}

  ngOnInit(): void {
    this.metadataService.getGenres().subscribe();
    this.metadataService.genres$.subscribe(genres => {
      this.genres = genres;
    });
  }
}
