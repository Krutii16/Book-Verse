import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-personalised',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  template: `
    <div class="min-h-screen bg-gray-50 py-12 px-4">
      <div class="max-w-2xl mx-auto">
        <h1 class="text-4xl font-bold mb-8">Personalised Search</h1>
        <div class="bg-white rounded-lg shadow-lg p-12">
          <p class="text-gray-600 mb-6">Search for books by keywords to get personalized recommendations.</p>
          <input type="text" placeholder="Enter a keyword..." class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4">
          <button class="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700">Search</button>
        </div>
      </div>
    </div>
  `
})
export class PersonalisedComponent {}
