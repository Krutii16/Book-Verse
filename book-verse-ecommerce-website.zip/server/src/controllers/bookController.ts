import { Request, Response } from 'express';
import Book from '../models/Book';

export const getAllBooks = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const books = await Book.find().skip(skip).limit(limit);
    const total = await Book.countDocuments();

    res.json({
      books,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getBookById = async (req: Request, res: Response) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json({ book });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const searchBooks = async (req: Request, res: Response) => {
  try {
    const { query } = req.query;
    if (!query) {
      return res.status(400).json({ error: 'Search query required' });
    }

    const books = await Book.find({
      $or: [
        { title: { $regex: query, $options: 'i' } },
        { author: { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } }
      ]
    });

    res.json({ books });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const filterBooks = async (req: Request, res: Response) => {
  try {
    const { genre, minPrice, maxPrice, rating, language, moods, keywords } = req.query;
    const filter: any = {};

    if (genre) filter.genre = genre;
    if (language) filter.language = language;
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = parseInt(minPrice as string);
      if (maxPrice) filter.price.$lte = parseInt(maxPrice as string);
    }
    if (rating) filter.rating = { $gte: parseInt(rating as string) };
    if (moods) filter.moods = { $in: Array.isArray(moods) ? moods : [moods] };
    if (keywords) filter.keywords = { $in: Array.isArray(keywords) ? keywords : [keywords] };

    const books = await Book.find(filter);
    res.json({ books });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getBestsellers = async (req: Request, res: Response) => {
  try {
    const books = await Book.find({ bestseller: true }).limit(20);
    res.json({ books });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getFeaturedBooks = async (req: Request, res: Response) => {
  try {
    const books = await Book.find().limit(12);
    res.json({ books });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const createBook = async (req: Request, res: Response) => {
  try {
    const book = new Book(req.body);
    await book.save();
    res.status(201).json({ message: 'Book created', book });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
};

export const updateBook = async (req: Request, res: Response) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!book) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json({ message: 'Book updated', book });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteBook = async (req: Request, res: Response) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json({ message: 'Book deleted' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
