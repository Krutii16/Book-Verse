import { Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { AdminGuard } from './core/guards/admin.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'books',
    loadComponent: () => import('./features/books/books.component').then(m => m.BooksComponent)
  },
  {
    path: 'books/:id',
    loadComponent: () => import('./features/books/book-detail/book-detail.component').then(m => m.BookDetailComponent)
  },
  {
    path: 'categories',
    loadComponent: () => import('./features/categories/categories.component').then(m => m.CategoriesComponent)
  },
  {
    path: 'bestsellers',
    loadComponent: () => import('./features/bestsellers/bestsellers.component').then(m => m.BestsellersComponent)
  },
  {
    path: 'moods',
    loadComponent: () => import('./features/moods/moods.component').then(m => m.MoodsComponent)
  },
  {
    path: 'personalised',
    loadComponent: () => import('./features/personalised/personalised.component').then(m => m.PersonalisedComponent)
  },
  {
    path: 'cart',
    loadComponent: () => import('./features/cart/cart.component').then(m => m.CartComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'checkout',
    loadComponent: () => import('./features/checkout/checkout.component').then(m => m.CheckoutComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    loadComponent: () => import('./features/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./features/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'contact',
    loadComponent: () => import('./features/contact/contact.component').then(m => m.ContactComponent)
  },
  {
    path: 'admin',
    canActivate: [AdminGuard],
    children: [
      {
        path: '',
        loadComponent: () => import('./features/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent)
      },
      {
        path: 'books',
        loadComponent: () => import('./features/admin/manage-books/manage-books.component').then(m => m.ManageBooksComponent)
      },
      {
        path: 'genres',
        loadComponent: () => import('./features/admin/manage-genres/manage-genres.component').then(m => m.ManreGenresComponent)
      },
      {
        path: 'moods',
        loadComponent: () => import('./features/admin/manage-moods/manage-moods.component').then(m => m.ManageMoodsComponent)
      },
      {
        path: 'orders',
        loadComponent: () => import('./features/admin/manage-orders/manage-orders.component').then(m => m.ManageOrdersComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];
