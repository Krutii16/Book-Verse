import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BookService } from '../../core/services/book.service';
import { MetadataService } from '../../core/services/metadata.service';
import { Book, Genre } from '../../core/models/book.model';

@Component({
  selector: 'app-books',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss']
})
export class BooksComponent implements OnInit {
  books: Book[] = [];
  genres: Genre[] = [];
  selectedGenre = '';
  minPrice = 0;
  maxPrice = 100;
  sortBy = 'latest';
  page = 1;
  loading = false;

  constructor(
    private bookService: BookService,
    private metadataService: MetadataService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(() => {
      this.loadBooks();
    });

    this.metadataService.getGenres().subscribe();
    this.metadataService.genres$.subscribe(genres => {
      this.genres = genres;
    });
  }

  loadBooks(): void {
    this.loading = true;
    this.route.queryParams.subscribe(params => {
      if (params['genre']) {
        this.selectedGenre = params['genre'];
      }
    });

    this.bookService.getAllBooks(this.page, 12).subscribe((response: any) => {
      this.books = response.books;
      this.loading = false;
    });
  }

  filterBooks(): void {
    this.loading = true;
    const filters: any = {
      genre: this.selectedGenre,
      minPrice: this.minPrice,
      maxPrice: this.maxPrice
    };

    this.bookService.filterBooks(filters).subscribe((response: any) => {
      this.books = response.books;
      this.loading = false;
    });
  }
}
