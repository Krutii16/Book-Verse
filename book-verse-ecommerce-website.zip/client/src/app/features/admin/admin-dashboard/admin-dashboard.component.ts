import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-gray-50 py-12 px-4">
      <div class="max-w-7xl mx-auto">
        <h1 class="text-4xl font-bold mb-12">Admin Dashboard</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Total Books</h3>
            <p class="text-4xl font-bold text-blue-600">150+</p>
          </div>
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Total Orders</h3>
            <p class="text-4xl font-bold text-green-600">1,234</p>
          </div>
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Total Revenue</h3>
            <p class="text-4xl font-bold text-purple-600">$45,892</p>
          </div>
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Total Users</h3>
            <p class="text-4xl font-bold text-orange-600">523</p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <a routerLink="/admin/books" class="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition cursor-pointer">
            <h2 class="text-2xl font-bold text-blue-600 mb-2">Manage Books</h2>
            <p class="text-gray-600">Add, edit, or delete books from the catalog</p>
          </a>
          <a routerLink="/admin/genres" class="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition cursor-pointer">
            <h2 class="text-2xl font-bold text-green-600 mb-2">Manage Genres</h2>
            <p class="text-gray-600">Organize and manage book categories</p>
          </a>
          <a routerLink="/admin/moods" class="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition cursor-pointer">
            <h2 class="text-2xl font-bold text-purple-600 mb-2">Manage Moods</h2>
            <p class="text-gray-600">Create and manage mood-based browsing</p>
          </a>
          <a routerLink="/admin/orders" class="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition cursor-pointer">
            <h2 class="text-2xl font-bold text-orange-600 mb-2">Manage Orders</h2>
            <p class="text-gray-600">View and update customer orders</p>
          </a>
        </div>
      </div>
    </div>
  `
})
export class AdminDashboardComponent {}
